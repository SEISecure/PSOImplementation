/**
 * Class representing a particle.
 */

import java.util.ArrayList; // import the ArrayList class

public class StrategyParticle {

	public double[] position; //The position vector of this particle
	
	public ArrayList<Double> fitness = new ArrayList<Double>(); //The fitness list over regions of this particle
	
	public double[] velocity; //The velocity vector of this particle
	public double[] personalBest; //Personal best of the particle
	public double bestFitness = Double.MAX_VALUE; //The best fitness of this particle

	public StrategyParticle(double[] position, double[] velocity) {
		this.position = position;
		this.velocity = velocity; 
	}

	public void resetFitness(){
		this.fitness  = new ArrayList<Double>(); 
	}
	public double returnFitnessIndex (int index){
		return fitness.get(index);
	}
	
}
