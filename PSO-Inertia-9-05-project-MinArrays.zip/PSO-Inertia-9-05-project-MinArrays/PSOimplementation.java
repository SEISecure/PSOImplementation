/**
 * Class implementing the PSO algorithm.
 */

//import java.util.ArrayList;
//import java.util.List;
//import java.io.BufferedReader;
//import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
//import java.io.FileReader;
import java.io.OutputStreamWriter;
//import java.util.ArrayList;
//import java.util.List;


public class PSOimplementation {

	public final int numDimensions = 8; //Number of dimensions for problem
	public final int numPaths = 3;//30; //Number of particles in swarm
	public final int maxIterations = 5;//00; //Max number of iterations
	public final double c1 = 0.5; //0.01496180; //Cognitive coefficient
	public final double c2 = 0.3; //0.01496180; //Social coefficient
	public final double w = 0.729844; //Inertia coefficient

	public  double[] r1; //Random vector 1
	public  double[] r2;  //Random vector 2
	public double[] best;
	double Mindistance = Double.MAX_VALUE;
	StrategyParticle[] particles; //Array to hold all particles

	//public int [] PathNumber;
	public double[][] Strategy;
	public double[][] StrategyVelocity;
	//public double [][][][] DistanceScenarioStrategy;
	public double [][] AverageDistanceScenarioBehavior;
	public double [] AverageDistanceBehavior;
	public String [] RegionNumber;
	int NumberOfStrategies;
	int NumberOfRegions;


	public PSOimplementation() {
		//PSO algorithm

		NumberOfStrategies = 2;
		NumberOfRegions = 2;

		//PathNumber = new int[20];
		Strategy = new double[NumberOfStrategies][8];
		StrategyVelocity = new double[NumberOfStrategies][8];
		//DistanceScenarioStrategy = new double[20][NumberOfRegions][NumberOfStrategies][8];
		AverageDistanceScenarioBehavior = new double [NumberOfRegions][NumberOfStrategies];
		AverageDistanceBehavior = new double[NumberOfStrategies];
		RegionNumber = new String[NumberOfRegions];
		RegionNumber[0] = "59919";
		RegionNumber[1] = "59922";
		//StrategyParticle[] particles = new StrategyParticle[4];
		//region 1
		//	the following could be implemented by random numbers in the future
		Strategy[0][0] = 0.5288983372203725; 
		Strategy[0][1] = 0.9971838385505777;
		Strategy[0][2] = 0.18802395499477664;
		Strategy[0][3] = 0.9057422479959465; 
		Strategy[0][4] = 0.001978865215885528; 
		Strategy[0][5] = 0.5747368847236165;
		Strategy[0][6] = 0.7406885587772201;
		Strategy[0][7] = 0.2641456108438227;

		StrategyVelocity[0][0] = 0.7559636106655413; 
		StrategyVelocity[0][1] = 0.08854723646159102;
		StrategyVelocity[0][2] = 0.6222524045549027;
		StrategyVelocity[0][3] = 0.014617171434887166; 
		StrategyVelocity[0][4] = 0.11800949653638171; 
		StrategyVelocity[0][5] = 0.38141522841673636;
		StrategyVelocity[0][6] = 0.40025926401496303;
		StrategyVelocity[0][7] = 0.06902778619810346;
		
		//particles[0].velocity =StrategyVelocity[0];
		//particles[0].position =Strategy[0];
		
		Strategy[1][0] = 0.9213828732151677; 
		Strategy[1][1] = 0.9780080705396429;
		Strategy[1][2] = 0.42988331864703977;
		Strategy[1][3] = 0.8478708974275867; 
		Strategy[1][4] = 0.13543529690884826; 
		Strategy[1][5] = 0.9930646013228468;
		Strategy[1][6] = 0.05319602604145912;
		Strategy[1][7] = 0.5127400874470203;

		StrategyVelocity[1][0] = 0.4249242757317312; 
		StrategyVelocity[1][1] = 0.42293610162625883;
		StrategyVelocity[1][2] = 0.8752856175170971;
		StrategyVelocity[1][3] = 0.3253769270493324; 
		StrategyVelocity[1][4] = 0.8688794060573191; 
		StrategyVelocity[1][5] = 0.6706235760163347;
		StrategyVelocity[1][6] = 0.7684540357656227;
		StrategyVelocity[1][7] = 0.1484924794421122;
		
		//particles[1].velocity =StrategyVelocity[1];
		//particles[1].position =Strategy[1];
		/*
		Strategy[2][0] = 0.08082056683692795; 
		Strategy[2][1] = 0.5863612437938057;
		Strategy[2][2] = 0.6946035006796163;
		Strategy[2][3] = 0.2556613143277917; 
		Strategy[2][4] = 0.7081350249301661; 
		Strategy[2][5] = 0.24029362764758888;
		Strategy[2][6] = 0.8806105148847431;
		Strategy[2][7] = 0.6396442821620925;

		
		StrategyVelocity[2][0] = 0.15839679525268147; 
		StrategyVelocity[2][1] = 0.262447454442456;
		StrategyVelocity[2][2] = 0.5945971217925762;
		StrategyVelocity[2][3] = 0.9070312463649481; 
		StrategyVelocity[2][4] = 0.7030211277100632; 
		StrategyVelocity[2][5] = 0.4029684589873901;
		StrategyVelocity[2][6] = 0.9280954958443773;
		StrategyVelocity[2][7] = 0.08809152366457584;
		

		Strategy[3][0] = 0.11007294426933589; 
		Strategy[3][1] = 0.6057601481727584;
		Strategy[3][2] = 0.4599852603112432;
		Strategy[3][3] = 0.008732558837202031; 
		Strategy[3][4] = 0.8189082218436358; 
		Strategy[3][5] = 0.5871315401811127;
		Strategy[3][6] = 0.23556166926440436;
		Strategy[3][7] = 0.9206543306108479;

		
		StrategyVelocity[3][0] = 0.9290711805628159; 
		StrategyVelocity[3][1] = 0.31618405078401723;
		StrategyVelocity[3][2] = 0.6979749184842595;
		StrategyVelocity[3][3] = 0.8850473467592296; 
		StrategyVelocity[3][4] = 0.6576451622863664; 
		StrategyVelocity[3][5] = 0.9566535207497756;
		StrategyVelocity[3][6] = 0.746435753324544;
		StrategyVelocity[3][7] = 0.5927717495450405;
		*/
		
		for (int i = 0; i < NumberOfRegions; i++)
			for (int j = 0; j < NumberOfStrategies; j++)
				AverageDistanceScenarioBehavior[i][j] = 0.0;

		for (int j = 0; j < NumberOfStrategies; j++)
			AverageDistanceBehavior[j] = 0.0;
		//endregion 1

	}

	public void run(){

		
		StrategyParticle[] particles = new StrategyParticle[4];
		//PSOEngine PSO = new PSOEngine();
		//double generalAverage = 0.0;
		//double totalAverage = 0.0;
		String messageT = "";

		//PSO loop
		int numIter = 0;
		//best = particles[0].position;

		//initalizes a single PSO engine and loadsparticles into list
        PSOEngine PSO = new PSOEngine(numDimensions, numPaths, maxIterations, c1, c2, w);
        for (int StrategyIndex =0; StrategyIndex < NumberOfStrategies; StrategyIndex++){
            particles[StrategyIndex] = new StrategyParticle(Strategy[StrategyIndex], StrategyVelocity[StrategyIndex]);
            //Initialize particles
			PSO.initParticles(Strategy[StrategyIndex], StrategyVelocity[StrategyIndex], particles);
        }


		while (numIter<maxIterations) {		//	loop over swarm 'time step'
			//generalAverage = 0.0;
			
			for (int StrategyIndex =0; StrategyIndex < NumberOfStrategies; StrategyIndex++){	//	loop over Strategies

				AverageDistanceBehavior[StrategyIndex] = 0.0;	
				//generalAverage = 0.0;

				for (int RegNr = 0; RegNr < NumberOfRegions; RegNr++) {	//	loop over regions-scenarios
                    PSO.setRegion(RegionNumber[RegNr]);
                    
					messageT = "time: " + numIter + " strategy: " + StrategyIndex + " region: "+ RegionNumber[RegNr];
					
							

					
	
					
					//region mesage1

					
					//String message1 = "particles : ," + particles[0][StrategyIndex][RegNr].position[0] + "," +
					//	particles[StrategyIndex][RegNr][0].position[1] + "," +  particles[StrategyIndex][RegNr][0].position[2] + "," +  
					//	particles[StrategyIndex][RegNr][0].position[3] + "," +  particles[StrategyIndex][RegNr][0].position[4] + "," +  
					//	particles[StrategyIndex][RegNr][0].position[5]+ "," +  particles[StrategyIndex][RegNr][0].position[6] + "," +  
					//	particles[StrategyIndex][RegNr][0].position[7];
				
					//String message2 = "velocities : ," + particles[StrategyIndex][RegNr][0].velocity[0] + "," +
					//	particles[StrategyIndex][RegNr][0].velocity[1] + "," +  particles[StrategyIndex][RegNr][0].velocity[2] + "," +  
					//	particles[StrategyIndex][RegNr][0].velocity[3] + "," +  particles[StrategyIndex][RegNr][0].velocity[4] + "," +  
					//	particles[StrategyIndex][RegNr][0].velocity[5] + "," +  particles[StrategyIndex][RegNr][0].velocity[6] + "," +  
					//	particles[StrategyIndex][RegNr][0].velocity[7] ;
					
					//messageT = messageT + "," + message1 + "," + message2;
					//endregion message1
					// Evaluate fitness of each particle

					//	the following has to be updated with Step 4
					for (int i3=0; i3<numPaths; i3++) {		//	loop over 'person-particles'

						particles[StrategyIndex].fitness.add( PSO.evaluateFitness(particles[StrategyIndex].position));

						//region fitness
						writeToLogFile(messageT + " pathNr: " + i3 + " fitness : " + particles[StrategyIndex].returnFitnessIndex(i3));
						//endregion fitness

                   
					}
					//Find best particle in set
					//int best_index = PSO[StrategyIndex][RegNr].findBest(particles[StrategyIndex][RegNr]);
					//best = particles[StrategyIndex][RegNr][best_index].personalBest;

					//Find average fitness
					AverageDistanceScenarioBehavior[RegNr][StrategyIndex] = 0.0;
					for (int i4=0; i4<numPaths; i4++) {
						AverageDistanceScenarioBehavior[RegNr][StrategyIndex] += particles[StrategyIndex].returnFitnessIndex(i4);
					}
					AverageDistanceScenarioBehavior[RegNr][StrategyIndex] /= (double)numPaths;
					writeToLogFile(messageT + " AverageDistanceScenarioBehavior: " + AverageDistanceScenarioBehavior[RegNr][StrategyIndex]);
					particles[StrategyIndex].resetFitness();
					AverageDistanceBehavior[StrategyIndex] += 	AverageDistanceScenarioBehavior[RegNr][StrategyIndex] ;
				}	//	loop over regions-scenarios	
				//	here has to divide by the number of regions 
				AverageDistanceBehavior[StrategyIndex] /= (double)NumberOfRegions;
				writeToLogFile("time: " + numIter + " strategy: " + StrategyIndex + " AverageDistanceBehavior: " + AverageDistanceBehavior[StrategyIndex]);
				//writeToLogFile("time: " + numIter + " 111");
			}	//	loop over Strategies 
			//writeToLogFile("time: " + numIter + " 1a");
			/********************************************************** */
			//	here we need to write the correct code in terms of the averages over Step 4
			//	first we need to find the  particle with the closest fitness to the average, and from 
			//	there, we define it to be the best 
			for (int StrategyIndex =0; StrategyIndex < NumberOfStrategies; StrategyIndex++){	//	loop over Strategies
				//writeToLogFile("time: " + numIter + " 1b");
				//Check to see if this particle has performed the best it has ever performed
				if( AverageDistanceBehavior[StrategyIndex] < particles[StrategyIndex].bestFitness) { //} PSO.evaluateFitness(particles[i].personalBest)) {
					particles[StrategyIndex].personalBest = particles[StrategyIndex].position.clone();
					particles[StrategyIndex].bestFitness = AverageDistanceBehavior[StrategyIndex];
				}
				//Check to see if this particle is the global best 
				if (AverageDistanceBehavior[StrategyIndex] < Mindistance){
					this.best = particles[StrategyIndex].position.clone();
					this.Mindistance = AverageDistanceBehavior[StrategyIndex];
					
				}
			}
				
			//}

			//writeToLogFile("time: " + numIter + " 111b");
	
			//updating particle velocity based on global and personal best
			//PSOEngine PSOUpdater = new PSOEngine(numDimensions, numParticles, maxIterations, c1, c2, w, 0,
			//									RegionNumber[0]);
			
			//Initialize the random vectors for updates
			r1 = new double[numDimensions];
			r2 = new double[numDimensions];
			for (int i5=0; i5<numDimensions; i5++) {
				r1[i5] = Math.random();
				r2[i5] = Math.random();
			}
			//writeToLogFile("time: " + numIter + " 111c");
			for (int StrategyIndex =0; StrategyIndex < NumberOfStrategies; StrategyIndex++){
					PSO.updateVelocity(particles[StrategyIndex], best, r1, r2);
					PSO.updatePosition(particles[StrategyIndex]);
			}
			numIter++;
			//writeToLogFile("time: " + numIter );//+ " best fitness: " + bestFitness);
		
		}	 //	loop over swarm 'time step'	
	}


	/**
	 * Helped method to print an array as a vector
	 * @param a The given 1-D array
	 */
	public void print (double[] a) {
		System.out.print("< ");
		for (int i=0; i<a.length; i++) {
			System.out.print(a[i]  + " ");
		}
		System.out.println(" > ");

	}

	public void printMessage (String message) {
		System.out.print(message);
	}


	public static void main(String[] args) {

		PSOimplementation p = new PSOimplementation(); 
		p.run();

		System.exit(0);	
	}

		/*
	 * writeToLogFile() is the low level function that writes the string
	 * provided to it to the SEILoggingFile.txt file for logging purposes
	 */
	private static void writeToLogFile(String line) {
		System.out.println(line);
		//String fileName = "TestPSOimpl_"+ String.valueOf(MainLoopIndex) +"_.txt";
		String fileName = "TestPSOimpl.txt";
		try {
            FileOutputStream fos = new FileOutputStream(fileName, true);    
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write("hello: " + line + "\n");
            bw.close();
			fos.close();
        }  catch (Exception e) {
            e.printStackTrace();
            System.out.println("astar logging, error");
        }
	
	}

}