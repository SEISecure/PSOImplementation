// AStar.java
//package com.bbn.example;
/*
 * SEI created the AStar class as a java implementation
 * of the Pathfinding Algorithm.  For an explanation of this code see:
 * Coding Challenge 51.1: A* Pathfinding Algorithm - Part 1 - YouTube
 * https://www.youtube.com/watch?v=aKYlikFAV4k&t=328s
 * Coding Challenge 51.2: A* Pathfinding Algorithm - Part 2 - YouTube
 * https://www.youtube.com/watch?v=EaZxUCWAjb0
 * Coding Challenge 51.3: A* Pathfinding Algorithm - Part 3 - YouTube
 * https://www.youtube.com/watch?v=jwRT4PCT6RU
 * The entry point to search for a  path given the initial point
 * and the destination point is the run() function
 * MapNode is a class associated with the land properties at the position of a person
 * MapUnit is a class associated with unfriendly units
 */

import java.awt.Toolkit;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.Serializable;
import java.io.FileReader;
import java.util.*;
import java.lang.Math;


public final class AStar_PSO_LostHiker {

   //Integer MainLoopIndex = 0;

   public static final class LatLongPoint extends Point2D.Double {

      LatLongPoint(double latitude, double longitude){
         setLocation(longitude, latitude);
      }

      double getLatDeg() {
         return getY();
      }
 
      double getLonDeg() {
         return getX();
      }

}

   /*
    * MapNode is a class that is used to describe a possible location of a lost person
    * including an ID for that location, the latitude, longitude, a list of neighbor locations
    * and terrain-cover properties 
    */
   public static final class MapNode implements Serializable {
      private String id;
      public LatLongPoint Point;
      //private  Double elevation;
      private  String list_of_neighbors;
      private int quality;

      public String getId() {
         return id;
      }

      public double getLatitude() {
         return Point.getLatDeg();
      }

      public double getLongitude() {
         return (Point.getLonDeg());
      }

      /*
      public NodeTerrain getTerrain() {
         return terrain;
      }
      */
      public int getQuality() {
         return quality;
      }

      public String getList_of_neighbors() {
         return list_of_neighbors;
      }

      private MapNode() {
      }

      public MapNode(String ID, double latitude, double longitude) {
         this.id = ID;
         this.Point = new LatLongPoint(latitude, longitude);  
      }

      public void setId(String ID) {
         this.id = ID;
      }
   
      public void setQuality(int quality) {
         this.quality = quality;
      }

   }
   
   
   /*
    * MapUnit is a class that is used to describe a location of an unfriendly person
    * including a name for the person or unit, the latitude, longitude, and the side and type to
    * which that person belongs 
    */
   public static final class MapUnit implements Serializable  {
      public LatLongPoint mpPoint;
      private final String name;
      private String side;
      private String type;

      public double getLatitude() {
         return this.mpPoint.getLatDeg();
      }

      public double getLongitude() {
         return (this.mpPoint.getLonDeg());
      }

      public String getName() {
         return name;
      }

      public String getSide() {
         return side;
      }

      public String getType() {
         return type;
      }

      public MapUnit() {
         this.name = "";
         this.mpPoint = new LatLongPoint(0.0, 0.0);
         this.side = "";
         this.type = "";
      }

      public MapUnit(String name, double latitude, double longitude) {
         this.name = name;
         this.mpPoint = new LatLongPoint(latitude, longitude);  
      }

   }
 
   public static final class Cell {
      public int i;
      public int j;

      public Cell(int i, int j){
         this.i = i;
         this.j = j;
      }

      int dotProduct (Cell argument) {
         int result = this.i * argument.i + this.j * argument.j;
         return result;
      }
   }

   /*  WalkStrategy is an enum specifying what type of walk strategy the agent is using
    */
    public enum WalkStrategy {
      DirectionTraveling,
      RandomWalk,
      RouteTraveling,
      StayingPut,
      ViewEnhancing,
      Backtracking,
      Inertia,
      Interrupt
   }

   public String[] Walkvalues = {"DirectionTraveling", "RandomWalk", "RouteTraveling", 
                  "ViewEnhancing", "StayingPut", "Backtracking", "Inertia", "Interrupt"};
 
   private Random rand = new Random(); 

   /* mTerrainArray is a double array providing the elevation of 
    * the locations in consideration
    */
   private Double[][] mElevationArray;

   /* mTerrainSecondArray is a int array to be used in possible extensions of the code 
   */
   private int[][] mTerrainSecondArray;

   /*
    * mHorizontalSize and mVerticalSize are the dimensions of the mTerrainArray double array
    */
   public int mHorizontalSize  = 0;
   public int mVerticalSize  = 0;
   public double mlat_lowerLeft = 0.0D;
   public double mlong_lowerLeft = 0.0D;
   public double mlat_upperRight = 0.0D;
   public double mlong_upperRight = 0.0D;

   Double LatitudeIPPcoordinates;
   Double LongitudeIPPcoordinates;
   public String StartPointStr ="";
   String RegionNr;
   public Point2D.Double StartPoint;
   Cell StartPointCell;

   Double LatitudeFindcoordinates;
   Double LongitudeFindcoordinates;
   String FoundPointStr;
   public Point2D.Double FoundPoint;
   Cell FoundPointCell;

   Double NotifyDays;
   Double SearchDays;

   //MyPanel panel;
   //JFrame frame;

   private List<MapNode> mNodeList;

   public void setRegion(String RegionNr)
   {
      if (RegionNr.equals(this.RegionNr) == false) {
         // here we read the file containing the types of cover for all the locations of interest for the code
         ReadFiles(RegionNr);
         // here we fill the list of  locations in the mNodeList , including neighbors
         fillNodeList(); 
         this.RegionNr = RegionNr;
      }
   }

   // Constructor
   public AStar_PSO_LostHiker() {

   

   }

   public List<MapNode> getNodesMaps(){
      return mNodeList;
   }

   // here we fill the list of  locations in the mNodeList , including neighbors
   private void fillNodeList(){

      // create the matrix array with points
      mNodeList = null;
      mNodeList = new ArrayList<>();
      String ID ;
      int iID = 0;
      for (int j = 0; j < mVerticalSize; j++){
         for (int i = 0; i < mHorizontalSize; i++)  {
            iID = mHorizontalSize * j + i + 1;
            ID = Integer.toString(iID);
            MapNode Node = getPositionFromIJ(i, j);
            Node.setId(ID);
            //Node.setElevation(mElevationArray[i][j]);
            Node.setQuality(mTerrainSecondArray[i][j]);

            // fill the list of neighbors for each point
            String neighb1 = "";
            for (int neighborI = -1; neighborI < 2; neighborI++) {
               for (int neighborJ = -1; neighborJ < 2; neighborJ++) {
                  if ((neighborI + i < 0) || (neighborI + i >= mHorizontalSize) ||
                          (neighborJ + j < 0) || (neighborJ + j >= mVerticalSize) ||
                          ((neighborI == 0) && (neighborJ == 0)))  continue;
                  int neighborintID = iID + mHorizontalSize * neighborJ + neighborI;
                  String neighborID = Integer.toString(neighborintID);
                  if (neighborID != null){
                     if (Node.list_of_neighbors == "")  neighb1 = neighborID;
                     else neighb1 = Node.list_of_neighbors + "," + neighborID;
                     Node.list_of_neighbors = neighb1;
                  }
               }
            }
            mNodeList.add(Node);
         }
      }

   }

   // here we read the file containing the types of cover for all the locations of interest for the code
   private void ReadFiles(String RegionNr)  {

      // Read the Borders file

      try {
         String fileName = "./Borders_" + RegionNr + ".txt";

         FileReader Borders = new FileReader(fileName);
         BufferedReader reader = new BufferedReader(Borders);
         String thisLine = reader.readLine();
         thisLine = reader.readLine();
         reader.close();
         Borders.close();

         String [] values = thisLine.split(",");

         // modified 8/8/23
         mlat_lowerLeft = Double.parseDouble(values[1]);
         mlong_lowerLeft = Double.parseDouble(values[2]);
         mlat_upperRight = Double.parseDouble(values[3]);
         mlong_upperRight = Double.parseDouble(values[4]);

      }  catch (Exception e) {
         e.printStackTrace();
         //String err = e.toString();
      }
      
        // Read the Roads file
     
      try {
         String fileName = "./roads_data_" + RegionNr + ".txt";

         List<String[]> lines = new ArrayList<String[]>();
         FileReader RoadsFile = new FileReader(fileName);
         BufferedReader reader = new BufferedReader(RoadsFile);
         String thisLine = reader.readLine();

         while (thisLine != null) {
            String [] values = thisLine.split(",");
            lines.add(values);
            thisLine = reader.readLine();
         }
         reader.close();
         RoadsFile.close();

         mVerticalSize = lines.size();
         mHorizontalSize = lines.get(0).length;
         // convert our list to a double array of NodeTerrains.
         mTerrainSecondArray = null;
         mTerrainSecondArray = new int[mHorizontalSize][mVerticalSize];
         for (int i = 0; i < mHorizontalSize; i++){   // x horizontal are the different elements in a line
            for (int j = 0; j < mVerticalSize; j++){   // y  vertical are the different lines
               mTerrainSecondArray[i][j] = (int)Double.parseDouble(lines.get(j)[i]);
            }
         }
      }  catch (Exception e) {
         e.printStackTrace();
         //String err = e.toString();
      }

       // Read the Elevation file
     
      try {
         String fileName = "./elv_data_" + RegionNr + ".txt";

         List<String[]> lines = new ArrayList<String[]>();
         FileReader ElevationFile = new FileReader(fileName);
         BufferedReader reader = new BufferedReader(ElevationFile);
         String thisLine = reader.readLine();

         while (thisLine != null) {
            String [] values = thisLine.split(",");
            lines.add(values);
            thisLine = reader.readLine();
         }
         reader.close();
         ElevationFile.close();

         // convert our list to a double array of NodeTerrains.
         mElevationArray = null;
         mElevationArray = new Double[mHorizontalSize][mVerticalSize];
         for (int i = 0; i < mHorizontalSize; i++){   // x horizontal are the different elements in a line
            for (int j = 0; j < mVerticalSize; j++){   // y  vertical are the different lines
               mElevationArray[i][j] = Double.parseDouble(lines.get(j)[i]);
            }
         }
      }  catch (Exception e) {
         e.printStackTrace();
         //String err = e.toString();
      }
      
      // Read the List file

      try {
         String fileName = "./searchFilteredDown" + RegionNr + ".txt";

         FileReader Borders = new FileReader(fileName);
         BufferedReader reader = new BufferedReader(Borders);
         String thisLine = reader.readLine();
         thisLine = reader.readLine();
         reader.close();
         Borders.close();

         String [] values = thisLine.split(",");

         NotifyDays = Double.parseDouble(values[12]);
         SearchDays = Double.parseDouble(values[13]);

         // added 8/8/23
         LatitudeIPPcoordinates = Double.parseDouble(values[14].replaceAll("\"", ""));
         LongitudeIPPcoordinates = Double.parseDouble(values[15].replaceAll("\"", ""));

         LatitudeFindcoordinates = Double.parseDouble(values[16].replaceAll("\"", ""));
         LongitudeFindcoordinates = Double.parseDouble(values[17].replaceAll("\"", ""));
   
      }  catch (Exception e) {
         e.printStackTrace();
         //String err = e.toString();
      }
      
      StartPointStr = FindNodeIDfromLatLon(LatitudeIPPcoordinates, LongitudeIPPcoordinates);
      StartPointCell = getCellFromNodeID(StartPointStr);
      StartPoint = new Point2D.Double(LatitudeIPPcoordinates, LongitudeIPPcoordinates);
      FoundPointStr = FindNodeIDfromLatLon(LatitudeFindcoordinates, LongitudeFindcoordinates);
      FoundPointCell = getCellFromNodeID(FoundPointStr);
      FoundPoint = new Point2D.Double(LatitudeFindcoordinates, LongitudeFindcoordinates);
 
      return;
   }
  
   /*
    * This is the main function in Star, it finds the path starting at the initial point
    *  and finishing at the endpoint if possible
    */
   public double run(double[] positions)  {
      
      String startNode = StartPointStr;
      List<String> Path = new ArrayList<>();
      String newPoint = startNode;
      String PreviousNode = startNode;
      int indexNr = (int)(8.0 * rand.nextDouble());
      

      String presentNode = this.getNeighbors(startNode).get(indexNr);
      //System.out.println("first neighbor indexNr: " + indexNr);
   
      float agentSpeed = 1.5f; // meters per second  it may be multiplied by a random number between 0-1
      float timeStep = 10.0f / agentSpeed;   //  10 is the size in meters of the simulation cell
      float totalSeconds = (float)(NotifyDays + SearchDays) * 3600.0f * 24.0f;
      int StepsNumber = (int) Math.round (totalSeconds / timeStep);

      WalkStrategy previousTrategy = WalkStrategy.DirectionTraveling;
      WalkStrategy mStrategy = previousTrategy;
      boolean agentPerformingRouteTraveling = false;
      Cell thisCell = getCellFromNodeID(presentNode);

      StepsNumber = 50;  //1000;    // this is only for testing purposes
      for (int counter = 0;  counter < StepsNumber ; counter++){
 
         if (counter == 0) mStrategy =FindRoyBWalkStrategy(positions);
         else if (positions[WalkStrategy.Inertia.ordinal()] >  Math.random()){ // checks to see if agent is willing to consider a new strategy
            if (mTerrainSecondArray[thisCell.i][thisCell.j] == 1 && 
                                    agentPerformingRouteTraveling ==true)  {
               if (positions[WalkStrategy.Interrupt.ordinal()] > Math.random()) mStrategy = FindRoyBWalkStrategy(positions);
            }
            else mStrategy = FindRoyBWalkStrategy(positions);
         }
          
       
         Cell presentCell = getCellFromNodeID(presentNode);
         Cell previousCell = getCellFromNodeID(PreviousNode);
         Cell heading = new Cell(presentCell.i - previousCell.i, presentCell.j - previousCell.j);

         // find newPoint for RandomWalk
         
         List<String> neighbors = this.getNeighbors(presentNode);
         if (mStrategy == WalkStrategy.DirectionTraveling)  {
            newPoint = selectDTPoint(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = false;
         }
         else if (mStrategy == WalkStrategy.RandomWalk) {
            newPoint = selectPlaceRandomly(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = false;
            }
         else if (mStrategy == WalkStrategy.RouteTraveling)  {
            newPoint = selectRTPoint(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = true;
            }
         else if (mStrategy == WalkStrategy.ViewEnhancing)  {
            newPoint = selectVEPoint(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = false;
            }
         else if (mStrategy == WalkStrategy.StayingPut)  {
            newPoint = selectSPPoint(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = false;
            }
         else if (mStrategy == WalkStrategy.Backtracking)  {
            newPoint = selectBKPoint(neighbors, presentCell, presentNode, heading);
            agentPerformingRouteTraveling = false;
         }
         
         previousTrategy = mStrategy;

         Path.add(newPoint);
         PreviousNode = presentNode;
         presentNode = newPoint;

   
      }

      Cell lastPointCell = getCellFromNodeID(Path.get(Path.size() - 1));
      Point2D.Double lastPoint = new Point2D.Double(lastPointCell.i, lastPointCell.j);
      Point2D.Double Found_1 = new Point2D.Double(FoundPointCell.i, FoundPointCell.j);
      double finalDistance = lastPoint.distance(Found_1);
   
      Toolkit.getDefaultToolkit().beep();   

      return finalDistance;

    }

       
   private WalkStrategy FindRoyBWalkStrategy(double[] positions){

      double strategyProb = Math.random();
      double effectiveProbDT = positions[WalkStrategy.DirectionTraveling.ordinal()];
      double effectiveProbRW = effectiveProbDT + positions[WalkStrategy.RandomWalk.ordinal()];
      double effectiveProbRT = effectiveProbRW + positions[WalkStrategy.RouteTraveling.ordinal()];
      double effectiveProbVE = effectiveProbRT + positions[WalkStrategy.ViewEnhancing.ordinal()];
      double effectiveProbSP = effectiveProbVE + positions[WalkStrategy.StayingPut.ordinal()];
      //double effectiveTotalProb = effectiveProbSP + positions[WalkStrategy.Backtracking.ordinal()];

      
      if (effectiveProbDT  >= strategyProb) return WalkStrategy.DirectionTraveling;
      else if (effectiveProbRW >= strategyProb) return WalkStrategy.RandomWalk;
      else if (effectiveProbRT >= strategyProb) return WalkStrategy.RouteTraveling;
      else if (effectiveProbVE >= strategyProb) return WalkStrategy.ViewEnhancing;
      else if (effectiveProbSP >= strategyProb) return WalkStrategy.StayingPut;
      else return WalkStrategy.Backtracking;

    }
   
  
   public String  selectPlaceRandomly(List<String> neighbors, Cell presentCell, 
                     String presentNode, Cell heading){

      double bestProbability = 0.0D;
      String bestNeighbor = presentNode;
      for (String neighbor : neighbors)  {
         double probability = 0.0D;
         Cell tempCell = getCellFromNodeID(neighbor);
         Cell tempPath = new Cell(tempCell.i - presentCell.i, tempCell.j - presentCell.j);
         if (tempPath.dotProduct(heading) < 0)  probability = -1.0D;
         else probability = rand.nextDouble();
         if (probability > bestProbability){
            bestProbability = probability;
            bestNeighbor = neighbor;
         }
      }
      return bestNeighbor;
   }

   public String selectRTPoint(List<String> neighbors, Cell presentCell, 
                     String presentNode, Cell heading){

      String newPoint = presentNode;
      List<String> cellHasRoute = new ArrayList<>();
      for (String neighbor : neighbors)  {
         Cell tempCell = getCellFromNodeID(neighbor);
         Cell tempPath = new Cell(tempCell.i - presentCell.i, tempCell.j - presentCell.j);
         int hasRoute = 0;
         if ((tempCell.i >= 0) && (tempCell.j >= 0) && (tempCell.i < mHorizontalSize ) && 
               (tempCell.j < mVerticalSize))  hasRoute = mTerrainSecondArray[tempCell.i][tempCell.j];
         if ((tempPath.dotProduct(heading) >= 0) && (hasRoute == 1))  {
            cellHasRoute.add(neighbor);
         }
      }
      if (cellHasRoute.isEmpty()){
         newPoint = selectPlaceRandomly(neighbors, presentCell, presentNode, heading);
      }
      else if (cellHasRoute.size() == 1) {
         newPoint = cellHasRoute.get(0);
      }
      else {
         //newPoint = selectPlaceFomList(cellHasRoute, presentCell, presentNode, heading);
         // here change it
         int bestDotProduct = -1;
         String bestNeighbor = presentNode;
         for (String neighbor : cellHasRoute)  {
            Cell tempCell = getCellFromNodeID(neighbor);
            Cell tempPath = new Cell(tempCell.i - presentCell.i, tempCell.j - presentCell.j);
            int tempDotProduct = tempPath.dotProduct(heading);
            if (tempDotProduct > bestDotProduct){
               bestDotProduct = tempDotProduct;
               bestNeighbor = neighbor;
            }
         }
         newPoint = bestNeighbor;
      }
      return newPoint;
   }

   public String  selectDTPoint(List<String> neighbors, Cell presentCell, 
                  String presentNode, Cell heading){

      double bestDotProduct = 0.0D;
      String bestNeighbor = presentNode;
      for (String neighbor : neighbors)  {
         Cell tempCell = getCellFromNodeID(neighbor);
         Cell tempPath = new Cell(tempCell.i - presentCell.i, tempCell.j - presentCell.j);
         double dotProduct = tempPath.dotProduct(heading);
         if (dotProduct > bestDotProduct)  {
            bestNeighbor = neighbor;
            bestDotProduct = dotProduct;
         }
      }
      return bestNeighbor;
   }

   public String  selectVEPoint(List<String> neighbors, Cell presentCell, 
                  String presentNode, Cell heading){

      double highestElevation = 0.0D;
      String bestNeighbor = presentNode;
      for (String neighbor : neighbors)  {
         Cell tempCell = getCellFromNodeID(neighbor);
         double tempElevation = mElevationArray[tempCell.i][tempCell.j];
         if (tempElevation > highestElevation)  {
            bestNeighbor = neighbor;
            highestElevation = tempElevation;
         }
      }
      return bestNeighbor;
   }

   public String  selectSPPoint(List<String> neighbors, Cell presentCell, 
                  String presentNode, Cell heading){

      return presentNode;
   }

   public String  selectBKPoint(List<String> neighbors, Cell presentCell, 
                  String presentNode, Cell heading){

      double bestDotProduct = 0.0D;
      String bestNeighbor = presentNode;
      for (String neighbor : neighbors)  {
         Cell tempCell = getCellFromNodeID(neighbor);
         Cell tempPath = new Cell(tempCell.i - presentCell.i, tempCell.j - presentCell.j);
         double dotProduct = tempPath.dotProduct(heading);
         if (dotProduct < bestDotProduct)  {
            bestNeighbor = neighbor;
            bestDotProduct = dotProduct;
         }
      }
      return bestNeighbor;
   }

   /*
    * getNode returns the MapNode with the given "node" name in the mNodeList
    */
   public  MapNode getNode(String node) {
      MapNode mapNode = new MapNode();
      for (MapNode value : mNodeList) {
            if (Objects.equals(value.getId(), node)) {
               mapNode = value;
               break;
            }
      }
      return mapNode;
   }
    
   /*  getNeighbors() and parseNeighbors() together return a List of
    *   Strings with the names of the neighbors of "node"
    * 
    */
   public List<String> parseNeighbors(  String neighbors) {
      //writeToLogFile("in parseNeighbors input:  " + neighbors);
      String[] result1 = neighbors.split(",");
      List<String> result = new ArrayList<>();
      for (String word : result1) {
         if (!Objects.equals(word, "") && (word != null)  && !Objects.equals(word, "null")) result.add(word);
      }
      //writeToLogFile("in parseNeighbors output:  " + result.toString());
      return result;
   }

   private List<String> getNeighbors(String node) {

      MapNode theNode = getNode(node);
      String thisNeighbors = theNode.getList_of_neighbors();
      return this.parseNeighbors(thisNeighbors);
   }

	/*
	 * getPositionFromIJ() makes the translation from the i and j
	 * indeces of a location in the main matrix to the
	 * latitude and longitude of that given location.
    * The result is returned as a MapNode
	 */
   private MapNode getPositionFromIJ(int i, int j) {

		double upper_latitude = mlat_upperRight;
		double lower_latitude = mlat_lowerLeft;
		double right_longitude = mlong_upperRight;
		double left_longitude = mlong_lowerLeft;
		
		double deltaLat = lower_latitude - upper_latitude ;
		double deltaLong = right_longitude - left_longitude;

      double id = (double)i;   
      double jd = (double)j;
      double mVerticalSized = (double) mVerticalSize;
      double mHorizontalSized = (double) mHorizontalSize;
		double latitude = upper_latitude + deltaLat * (jd / mVerticalSized);
		double longitude= left_longitude + deltaLong * (id / mHorizontalSized);
      MapNode Position = new MapNode("", latitude, longitude);

      return Position;
   }

   public Cell getCellFromNodeID (String ID) {

      double id = Double.parseDouble(ID);	
      double jdo = (id - 1.0D) / mHorizontalSize;  // set to j	
		int j = (int) jdo;
		double jInt = (double)j;	
		double ido =  id - (mHorizontalSize * jInt) - 1.0D; //set to i
      int i = (int)ido;

      Cell cellNr = new Cell(i, j);
    
      return cellNr;
   }

   	/*
	 * FindNodeIDfromLatLon() makes the translation from the
	 * latitude and longitude of a given location, to the name
	 * of that location in the main matrix as a string
	 */
	public String FindNodeIDfromLatLon(double latitude, double longitude){

		double upper_latitude = mlat_upperRight;
		double lower_latitude = mlat_lowerLeft;
		double right_longitude = mlong_upperRight;
		double left_longitude = mlong_lowerLeft;
		
		double deltaLat = lower_latitude - upper_latitude ;
		double deltaLong = right_longitude - left_longitude;
  
		double jd =  (latitude - upper_latitude ) * (mVerticalSize / deltaLat);
		double id = (longitude - left_longitude) * (mHorizontalSize / deltaLong);
		int i = (int)id;
		int j = (int)jd;

		int iID = (int)mHorizontalSize * j + i + 1;
		String StrID = Integer.toString(iID);

			return StrID;
	}

}
