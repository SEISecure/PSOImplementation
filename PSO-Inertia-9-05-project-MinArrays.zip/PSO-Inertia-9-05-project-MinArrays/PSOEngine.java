//import java.util.ArrayList;
//import java.util.List;

//import java.io.BufferedWriter;
//import java.io.FileOutputStream;
//import java.io.OutputStreamWriter;

/**
 * Class representing the PSO Engine. This class implements all the necessary methods for initializing the swarm,
 * updating the velocity and position vectors, determining the fitness of particles and finding the best particle.
 */
public class PSOEngine {

    int numDimensions = 30; //Number of dimensions for problem
    int numParticles = 30; //Number of particles in swarm
    int maxIterations = 10000; //Max number of iterations
    double c1 = 1.496180; //Cognitive coefficient
    double c2 = 1.496180; //Social coefficient
    double w = 0.729844; //Inertia coefficient
    //double wInterrupt = 0.2; //0.0729844; //Inertia coefficient

    //int MainLoopIndex = 0;

    public AStar_PSO_LostHiker AStar;
    
    public PSOEngine (int numDimensions, int numParticles, int maxIterations, 
                double c1, double c2, double w ) {
        this.numDimensions = numDimensions;
        this.numParticles = numParticles;
        this.maxIterations = maxIterations;
        this.c1 = c1;
        this.c2 = c2;
        this.w = w;
        //this.wInterrupt = wInt;

        //MainLoopIndex = loopNumber;

        this.AStar = new AStar_PSO_LostHiker(); 

    }
    public void setRegion(String RegionNr){
        this.AStar.setRegion(RegionNr);
    }
    /**
     * Method to initialize the particles for PSO
     * @param particles The set of particles to initialize
     */
    public void initParticles(double [] Strat, double [] StratVel, StrategyParticle[] particles) {
        //For each particle

        for (int i=0; i<particles.length;i++) {
            double[] positions = new double[numDimensions];
            double[] velocities = new double [numDimensions];
            //For each dimension of the particle assign a random x value [-5.12,5.12] and velocity=0
            for (int j=0; j<numDimensions; j++) {
                positions[j] = Strat[j];;
                velocities[j] = StratVel[j];
            }
 
             //Create the particle
            particles[i] = new StrategyParticle(positions, velocities);
            //Set particles personal best to initialized values
            particles[i].personalBest = particles[i].position.clone();
            particles[i].bestFitness = Double.MAX_VALUE;
        }

    }
    /**
     * Method to update the velocities vector of a particle
     * @param particle The particle to update the velocity for
     */
    public void updateVelocity(StrategyParticle particle, double[] best, double[] r1, double[] r2) {
        //First we clone the velocities, positions, personal and neighbourhood best
        double[] velocities = particle.velocity.clone();
        double[] personalBest = particle.personalBest.clone();
        double[] positions = particle.position.clone();
        double[] bestNeigh = best.clone();

        double[] inertiaTerm = new double[numDimensions];
        double[] difference1 = new double[numDimensions];
        double[] difference2 = new double[numDimensions];

        double[] c1Timesr1 = new double[numDimensions];
        double[] c2Timesr2 = new double[numDimensions];

        double[] cognitiveTerm = new double[numDimensions];
        double[] socialTerm = new double[numDimensions];

        //Calculate inertia component
        for (int i=0; i<numDimensions; i++) {
            inertiaTerm[i] = w*velocities[i];
        }

        /*
        //System.out.println("inertiaTerm : " + inertiaTerm[0] + " " +
        //inertiaTerm[1] + " " +  inertiaTerm[2] + " " +  
        //inertiaTerm[3] + " " +  inertiaTerm[4] + " " +  
        //inertiaTerm[5] );
        */
        //Calculate the cognitive component

        //Calculate personal best - current position
        for (int i=0; i<numDimensions; i++) {
            difference1[i] = personalBest[i] - positions[i];
        }
    
        //Calculate c1*r1
        for (int i=0; i<numDimensions; i++) {
            c1Timesr1[i] = c1*r1[i];
        }

        //Calculate c1*r1*diff = cognitive term
        for (int i=0; i<numDimensions; i++) {
            cognitiveTerm[i] = c1Timesr1[i]*difference1[i];
        }
 
        /*
        System.out.println("positions : " + positions[0] + " " +
        positions[1] + " " +  positions[2] + " " +  
        positions[3] + " " +  positions[4] + " " +  
        positions[5] );

        System.out.println("difference1 : " + difference1[0] + " " +
        difference1[1] + " " +  difference1[2] + " " +  
        difference1[3] + " " +  difference1[4] + " " +  
        difference1[5] );

        System.out.println("cognitiveTerm : " + cognitiveTerm[0] + " " +
        cognitiveTerm[1] + " " +  cognitiveTerm[2] + " " +  
        cognitiveTerm[3] + " " +  cognitiveTerm[4] + " " +  
        cognitiveTerm[5] );
        */
 

        //Calculate the social term

        //Calculate neighbourhood best - current position
        for (int i=0; i<numDimensions; i++) {
            difference2[i] = bestNeigh[i] - positions[i];
        }

        //Calculate c2*r2
        for (int i=0; i<numDimensions; i++) {
            c2Timesr2[i] = c2*r2[i];
        }
        //Calculate c2*r2*diff2 = social component
        for (int i=0; i<numDimensions; i++) {
            socialTerm[i] = c2Timesr2[i]*difference2[i];
        }
        /*
        System.out.println("socialTerm : " + socialTerm[0] + " " +
        socialTerm[1] + " " +  socialTerm[2] + " " +  
        socialTerm[3] + " " +  socialTerm[4] + " " +  
        socialTerm[5] );
        */

        //Update particles velocity at all dimensions
        for (int i=0; i<numDimensions; i++) {
            particle.velocity[i] = inertiaTerm[i]+cognitiveTerm[i]+socialTerm[i];
        }
        /*
        String message = "velocities : " + particle.velocity[0] + " " +
        particle.velocity[1] + " " +  particle.velocity[2] + " " +  
        particle.velocity[3] + " " +  particle.velocity[4] + " " +  
        particle.velocity[5] ;
        System.out.println(message );
        writeToLogFile(message);
        */
     }

    /**
     * Method to update the positions vector of a particle
     * @param particle The particle to update the position for
     */

    public void updatePosition(StrategyParticle particle) {
        //Since new position is ALWAYS calculated after calculating new velocity, it is okay to just add old position to the current velocity (as velocity would have already been updated).
        for (int i=0; i<numDimensions; i++) {
            particle.position[i] = particle.position[i]+particle.velocity[i];

            //  these are the corrections to keep the positions inside some boundaries
            if (particle.position[i] < 0){
                particle.position[i] = 0;
                particle.velocity[i] =  Math.random()*0.1;
            }
            else if (particle.position[i] > 1){
                particle.position[i] = 1;
                particle.velocity[i] =  Math.random()*-0.1;
            }
        }

        /*
        String message = "particles : " + particle.position[0] + " " +
            particle.position[1] + " " +  particle.position[2] + " " +  
            particle.position[3] + " " +  particle.position[4] + " " +  
            particle.position[5];
        System.out.println(message);
        writeToLogFile(message);
        */  
    }

    /**
     * Method to find the best (fittest) particle from a given set of particles
     * @param particles The collection of particles to determine the best from
     * @return The best (fittest) particle from the collection of particles
     */
    public int findBest(StrategyParticle[] particles) {
        double bestFitness = Double.MAX_VALUE;
        int bestIndex = 0;
        for(int i=0; i<numParticles; i++) {
            if (particles[i].bestFitness <= bestFitness) {
                bestFitness = particles[i].bestFitness;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    /**
     * Method to calculate the fitness of a particle using the Rastrigin function
     * @param positions The position vector to evaluate the fitness for
     * @return The fitness of the particle
     */
    public double evaluateFitness(double[] positions) {
        
        double fitness = 0;
     
        fitness = AStar.run(positions);
        /*
        String message = "fitness: " + fitness;
        writeToLogFile(message);
        writeToLogFile("");
        System.out.println(message);
        */
        return fitness;
    }
    
    /*
	private static void writeToLogFile(String line) {
		String fileName = "TestPSOengine.txt";
		try {
            FileOutputStream fos = new FileOutputStream(fileName, true);    
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write("hello: " + line + "\n");
            bw.close();
			fos.close();
        }  catch (Exception e) {
            e.printStackTrace();
            System.out.println("astar logging, error");
            writeToLogFile("error in writing");
        }
        
	}
    */


}
